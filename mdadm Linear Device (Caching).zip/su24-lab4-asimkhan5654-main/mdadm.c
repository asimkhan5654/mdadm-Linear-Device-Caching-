#include <stdio.h>
#include <string.h>
#include <assert.h>
#include "mdadm.h"
#include "jbod.h"

// Static variables for tracking mounting and write permission state
static int mounted = 0;
static int write_permission = 0;

// Function for getting mounted state
// Returns current mounted state (1 if mounted, 0 otherwise).
int isMounted(void) 
{
  return mounted;
}

// Function for setting mounted state
// Parameters:- state: The updated state to be set (1 for mounted, 0 for unmounted).
void set_mounted(int state)
 {
  mounted = state;
}

// JBOD mounting function 
// Returns 1 if the mount operation was successful, -1 otherwise.
int mdadm_mount(void) 
{
  if (!isMounted()) 
  {
    int result = jbod_operation(JBOD_MOUNT, NULL);
    if (result == 0) 
    {
      set_mounted(1);
      return 1;
    }
  }
  return -1;
}

// JBOD unmounting function
// Returns 1 if the unmount operation was successful, -1 otherwise.
int mdadm_unmount(void) {
  if (isMounted()) {
    int result = jbod_operation(JBOD_UNMOUNT, NULL);
    if (result == 0) 
    {
      set_mounted(0);
      return 1;
    }
  }
  return -1;
}

// Function to grant write permission
// Returns 1 if the operation was successful, -1 otherwise.
int mdadm_write_permission(void) 
{
  if (!isMounted()) 
  {
    return -1; // Fail if system is not mounted
  }
  if (!write_permission) 
  {
    write_permission = 1; // Grant write permission
    return 1; // Success
  }
  return 0; // Fail if write permission was already granted
}

// Function to revoke write permission
// Returns 1 if the operation was successful, -1 otherwise.
int mdadm_revoke_write_permission(void) 
{
  if (!isMounted()) 
  {
    return -1; // Fail if system is not mounted
  }
  if (write_permission) 
  {
    write_permission = 0; // Revoke write permission
    return 1; // Success
  }
  return 0; // Fail if write permission was already revoked
}

// Helper function for reading and seeking operations on JBOD 
// Parameters:- disk_num: Disk number to seek, block_num: Block number to seek, temp_block: Pointer to buffer containing the read block
// Returns 0 if the operations were successful, -1 otherwise.
int perform_jbod_seek_and_read(uint32_t disk_num, uint32_t block_num, uint8_t *temp_block) 
{
  if (jbod_operation(JBOD_SEEK_TO_DISK | (disk_num << 6), NULL) != 0) 
  {
    return -1; // Seek to disk failed
  }
  if (jbod_operation(JBOD_SEEK_TO_BLOCK | (block_num << 10), NULL) != 0) 
  {
    return -1; // Seek to block failed
  }
  if (jbod_operation(JBOD_READ_BLOCK, temp_block) != 0) {
    return -1; // Read block failed
  }
  return 0; // Success
}

// Helper function for seeking and writing operations on JBOD
// Parameters:- disk_num: Disk number to seek, block_num: Block number to seek, temp_block: Pointer to buffer containing the data to write
// Returns 0 if the operations were successful, -1 otherwise.
int perform_jbod_seek_and_write(uint32_t disk_num, uint32_t block_num, const uint8_t *temp_block) 
{
  if (jbod_operation(JBOD_SEEK_TO_DISK | (disk_num << 6), NULL) != 0) 
  {
    return -1; // Seek to disk failed
  }
  if (jbod_operation(JBOD_SEEK_TO_BLOCK | (block_num << 10), NULL) != 0) 
  {
    return -1; // Seek to block failed
  }
  if (jbod_operation(JBOD_WRITE_BLOCK, (uint8_t *)temp_block) != 0) 
  {
    return -1; // Write block failed
  }
  return 0; // Success
}

// Function to read data from JBOD
// Parameters:- start_addr: Starting address to read from, read_len: Length of data to read, read_buf: Pointer to buffer containing the read data
// Returns total number of bytes read if successful, -1 otherwise.
int mdadm_read(uint32_t start_addr, uint32_t read_len, uint8_t *read_buf) 
{
  if (!isMounted()) 
  {
    return -1; // Fail if system is not mounted
  }
  if (read_len == 0 && read_buf == NULL) {
    return 0; // Allow reads of 0 length with NULL pointer
  }
  if (read_buf == NULL || read_len > 1024 || (start_addr + read_len) > (JBOD_NUM_DISKS * JBOD_DISK_SIZE)) 
  {
    return -1; // Parameter validation
  }

  uint32_t current_addr = start_addr;
  uint32_t buf_offset = 0;
  uint32_t remaining_len = read_len;

  while (remaining_len > 0) {
    uint32_t disk_num = current_addr / JBOD_DISK_SIZE;
    uint32_t block_num = (current_addr % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
    uint32_t block_offset = current_addr % JBOD_BLOCK_SIZE;
    uint32_t read_size = (block_offset + remaining_len > JBOD_BLOCK_SIZE) ? JBOD_BLOCK_SIZE - block_offset : remaining_len;

    uint8_t temp_block[JBOD_BLOCK_SIZE]; // Temporary buffer for holding block data

    // Check cache first
    if (cache_lookup(disk_num, block_num, temp_block) == -1) 
    {
      // If not in cache, perform JBOD read
      if (perform_jbod_seek_and_read(disk_num, block_num, temp_block) != 0) 
      {
        return -1; // Seek and read operation failed
      }
      // Insert read block into cache
      cache_insert(disk_num, block_num, temp_block);
    } else 
    {
      // Update the cache entry as it was accessed
      cache_update(disk_num, block_num, temp_block);
    }

    // Copy data to read_buf
    memcpy(read_buf + buf_offset, temp_block + block_offset, read_size);

    current_addr += read_size;
    buf_offset += read_size;
    remaining_len -= read_size;
  }

  return read_len; // Return total number of bytes read
}

// Function to write data to JBOD
// Parameters:- start_addr: Starting address to write to, write_len: Length of data to write, write_buf: Pointer to buffer containing data to write
// Returns total number of bytes written if successful, -1 otherwise.
int mdadm_write(uint32_t start_addr, uint32_t write_len, const uint8_t *write_buf) 
{
  if (!isMounted() || !write_permission) 
  {
    return -1; // Fail if system is not mounted/write permission is not granted
  }
  if (write_len == 0 && write_buf == NULL) 
  {
    return 0; // Allow writes of 0 length with NULL pointer
  }
  if (write_buf == NULL || write_len > 1024 || (start_addr + write_len) > (JBOD_NUM_DISKS * JBOD_DISK_SIZE)) {
    return -1; // Parameter validation
  }

  uint32_t current_addr = start_addr; // Start writing from the given start address
  uint32_t buf_offset = 0; // Keeps track of where we are in the write buffer
  uint32_t remaining_len = write_len; // Initialize length remaining to total length of data to be written

  while (remaining_len > 0)  // Loop until all the data has been written
  {
    // Calculation of disk number, block number, offset within block, size to write in iteration
    uint32_t disk_num = current_addr / JBOD_DISK_SIZE; 
    uint32_t block_num = (current_addr % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
    uint32_t block_offset = current_addr % JBOD_BLOCK_SIZE;
    uint32_t write_size = (block_offset + remaining_len > JBOD_BLOCK_SIZE) ? JBOD_BLOCK_SIZE - block_offset : remaining_len;

    uint8_t temp_block[JBOD_BLOCK_SIZE]; // Temp buffer for holding block data

    // If writing less than a full block, read block first to preserve unchanged data
    if (block_offset != 0 || write_size < JBOD_BLOCK_SIZE) 
    {
      if (perform_jbod_seek_and_read(disk_num, block_num, temp_block) != 0) 
      {
        return -1; // Seek and read operation failed
      }
    }

    // Copy data from write_buf to temp_block
    memcpy(temp_block + block_offset, write_buf + buf_offset, write_size);

    // Write updated block back to disk
    if (perform_jbod_seek_and_write(disk_num, block_num, temp_block) != 0) 
    {
      return -1; // Seek and write operation failed
    }

    // Update the cache with the written block
    cache_update(disk_num, block_num, temp_block);

    current_addr += write_size;
    buf_offset += write_size;
    remaining_len -= write_size;
  }

  return write_len; // Return total number of bytes written
}

