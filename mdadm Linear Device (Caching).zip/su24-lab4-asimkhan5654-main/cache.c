#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#include "cache.h"
#include "jbod.h"

static cache_entry_t *cache = NULL;
static int cache_size = 0;
static int num_queries = 0;
static int num_hits = 0;

int cache_create(int num_entries) 
{
  // Ensure number of entries is within valid range and cache isn't already created
  if (!(num_entries >= 2 && num_entries <= 4096) || cache != NULL) 
  {
    return -1;
  }

  // Allocate memory for cache entries
  cache = calloc(num_entries, sizeof(cache_entry_t));
  
  // Verify memory allocation
  if (cache == NULL) 
  {
    return -1;
  }

  // Initialize cache size
  cache_size = num_entries;
  return 1; // Show success
}

int cache_destroy(void) 
{
    // Check if cache isn't already destroyed
    if (!cache_enabled()) 
    {
        return -1;
    }

    // For the cache, free allocated memory 
    free(cache);
    cache = NULL;
    cache_size = 0;
    num_queries = 0;
    num_hits = 0;

    return 1; // Show success
}

int cache_lookup(int disk_num, int block_num, uint8_t *buf) 
{
    // Check if cache is enabled and buffer isn't NULL
    if (!cache_enabled() || buf == NULL) 
    {
        return -1;
    }

    // Increment number of queries
    num_queries++;

    // Iterate through cache to find block that is requested
    int i = 0;
    while (i < cache_size) 
    {
        if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num) 
        {
            // Copy block data to the provided buffer
            memcpy(buf, cache[i].block, JBOD_BLOCK_SIZE);

            // Update access count for cache entry
            cache[i].num_accesses++;

            // Increment number of hits
            num_hits++;

            return 1; // Show success
        }
        i++;
    }

    return -1; // Show fail if block isn't found in cache
}


void cache_update(int disk_num, int block_num, const uint8_t *buf) 
{
    // Check if cache is enabled and buffer isn't NULL
    if (!cache_enabled() || buf == NULL) 
    {
        return; // Exit if cache isn't enabled or buffer is NULL
    }

    // Iterating through cache entries 
    int i = 0;
    while (i < cache_size) 
    {
        // Check if current cache entry is valid & matches disk and block number
        if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num) 
        {
            // Copy provided buffer to cache block
            memcpy(cache[i].block, buf, JBOD_BLOCK_SIZE);

            // Incrementing access count for cache entry
            cache[i].num_accesses++;

            return; // Exit function after updating the cache entry
        }
        i++; // Next cache entry
    }
}


int cache_insert(int disk_num, int block_num, const uint8_t *buf) 
{
  // Ensure cache is initialized & parameters are valid
  if (cache == NULL || buf == NULL || disk_num < 0 || disk_num >= JBOD_NUM_DISKS || block_num < 0 || block_num >= JBOD_NUM_BLOCKS_PER_DISK) 
  {
    return -1; // Return fail if any check fails
  }

  // Check if block is already in the cache
  for (int i = 0; i < cache_size; i++) 
  {
    if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num) 
    {
      return -1; // Block already exists, return failure
    }
  }

  // Variables to track invalid entry &  least frequently used entry
  int lfu_index = -1;
  int i = 0;

  // Loop through cache to find invalid entry or least frequently used entry
  while (i < cache_size) 
  {
    if (!cache[i].valid) 
    {
      // If invalid entry is found, insert new block here
      memcpy(cache[i].block, buf, JBOD_BLOCK_SIZE);
      cache[i].disk_num = disk_num;
      cache[i].block_num = block_num;
      cache[i].valid = true;
      cache[i].num_accesses = 1;
      return 1; // Successfully inserted new block
    }
    // Keep track of least frequently used entry
    if (lfu_index == -1 || cache[i].num_accesses < cache[lfu_index].num_accesses) 
    {
      lfu_index = i;
    }
    i++;
  }

  // If no invalid entry was found, evict least frequently used entry and insert new block
  if (lfu_index != -1) 
  {
    memcpy(cache[lfu_index].block, buf, JBOD_BLOCK_SIZE);
    cache[lfu_index].disk_num = disk_num;
    cache[lfu_index].block_num = block_num;
    cache[lfu_index].valid = true;
    cache[lfu_index].num_accesses = 1;
    return 1; // Successfully replaced least frequently used block
  }

  return -1; // If logic is correct, should not reach till here, indicates unexpected error as all cases should be handled above
}


bool cache_enabled(void) 
{
    // Check if cache is initialized & has +ve size
    return cache != NULL && cache_size > 0;
}

void cache_print_hit_rate(void) 
{
    // For debugging: Print number of hits & queries to stderr
    fprintf(stderr, "num_hits: %d, num_queries: %d\n", num_hits, num_queries);

    // indicate hit rate isn't applicable, If no queries
    if (num_queries == 0) 
    {
        fprintf(stderr, "Hit rate: N/A\n");
    } 
    else 
    {
        // Calculate and print hit rate as percentage
        fprintf(stderr, "Hit rate: %5.1f%%\n", 100 * (float) num_hits / num_queries);
    }
}

